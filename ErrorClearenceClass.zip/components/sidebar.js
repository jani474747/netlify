function sidebar(){

    return`
    <div>Menu</div>
    <div>Login</div>
    <div>Sign Up</div>
    <input type="text" id = "searchbar"  />
     <div>News</div>
     <div>API</div>
     `;
}
export default sidebar;